import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class Main {

    public static void main(String[] args) {

    }
}
